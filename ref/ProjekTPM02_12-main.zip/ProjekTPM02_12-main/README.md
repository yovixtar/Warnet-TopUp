<img src="https://raw.githubusercontent.com/mkiisoft/Pokemon-List/master/assets/images/banner.png"/>

## Flutter - Pokemon List

|               List                 |              Pokedex               |
|:----------------------------------:|:----------------------------------:|
| <img src="https://raw.githubusercontent.com/mkiisoft/Pokemon-List/master/assets/images/screenshot_1.png" width="300px"/> | <img src="https://raw.githubusercontent.com/mkiisoft/Pokemon-List/master/assets/images/screenshot_2.png" width="300px"/> |

## Install

 - Download/Clone repo
 - Install libraries and dependencies `flutter pub get`
 - Run `main.dart`
