import 'dart:ui';

class AppConstants {
  static const Size designScreenSize = Size(375, 754);
}
