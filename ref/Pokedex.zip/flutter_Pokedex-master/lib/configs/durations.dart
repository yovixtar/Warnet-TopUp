const animationDuration = Duration(milliseconds: 260);
