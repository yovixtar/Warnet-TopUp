class AppFonts {
  static const circularStd = 'CircularStd';
}
