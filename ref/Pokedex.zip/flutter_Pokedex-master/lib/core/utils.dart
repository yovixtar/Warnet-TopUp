String getEnumValue(e) => e.toString().split('.').last;
